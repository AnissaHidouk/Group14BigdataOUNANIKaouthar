#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import json
get_ipython().run_line_magic('matplotlib', 'inline')
import matplotlib.pyplot as plt
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, confusion_matrix, precision_recall_curve)


# In[4]:


data = pd.read_csv('/Users/AnissaHidouk/Downloads/breast-cancer-data.csv')
data.info()


# In[5]:


X = data.drop(columns=['diagnosis'])
y = data['diagnosis'].map({'malignant': 1, 'benign': 0}.get).values


# In[6]:


X_train, X_test, y_train, y_test = train_test_split(X, y,                                    test_size=0.2, random_state=11)
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)


# In[7]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_
size=0.2, random_state=11)
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)


# In[8]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=11)
print(X_train.shape)
print(y_train.shape)
print(X_test.shape)
print(y_test.shape)


# In[9]:


meta_gbc = GradientBoostingClassifier()
param_dist = {
    'n_estimators': list(range(10, 210, 10)),
    'criterion': ['mae', 'mse'],
    'max_features': ['sqrt', 'log2', 0.25, 0.3, 0.5, 0.8, None],
    'max_depth': list(range(1, 10)),
    'min_samples_leaf': list(range(1, 10))
}


# In[10]:


rand_search_params = {
    'param_distributions': param_dist,
    'scoring': 'accuracy',
    'n_iter': 100,
    'cv': 5,
    'return_train_score': True,
    'n_jobs': -1,
    'random_state': 11
}

random_search = RandomizedSearchCV(meta_gbc, **rand_search_params)
random_search.fit(X_train, y_train)


# In[11]:


param_dist = {
    'n_estimators': list(range(10, 210, 10)),
    'criterion': ['squared_error', 'friedman_mse'],
    'max_features': ['sqrt', 'log2', 0.25, 0.3, 0.5, 0.8, None],
    'max_depth': list(range(1, 10)),
    'min_samples_leaf': list(range(1, 10))
}


# In[12]:


idx = np.argmax(random_search.cv_results_['mean_test_score'])
final_params = random_search.cv_results_['params'][idx]
final_params


# In[13]:


train_X, val_X, train_y, val_y = train_test_split(X_train, y_train,
test_size=0.15, random_state=11)
train_X.shape, train_y.shape, val_X.shape, val_y.shape


# In[14]:


gbc = GradientBoostingClassifier(**final_params)
gbc.fit(train_X, train_y)
preds_train = gbc.predict(train_X)
preds_val = gbc.predict(val_X)
pred_probs_val = np.array([each[1] for each in gbc.predict_
proba(val_X)])


# In[16]:


gbc = GradientBoostingClassifier(**final_params)
gbc.fit(train_X, train_y)
preds_train = gbc.predict(train_X)
preds_val = gbc.predict(val_X)
pred_probs_val = np.array([each[1] for each in gbc.predict_proba(val_X)])


# In[17]:


print('train accuracy_score = {}'.format(accuracy_score(y_true=train_y, y_pred=preds_train)))
print('validation accuracy_score = {}'.format(accuracy_score(y_true=val_y, y_pred=preds_val)))
print('confusion_matrix: \n{}'.format(confusion_matrix(y_true=val_y, y_pred=preds_val)))
print('precision_score = {}'.format(precision_score(y_true=val_y, y_pred=preds_val)))
print('recall_score = {}'.format(recall_score(y_true=val_y, y_pred=preds_val)))


# In[18]:


plt.figure(figsize=(10,7))
precision, recall, thresholds = precision_recall_curve(val_y, pred_probs_val)
plt.plot(recall, precision)
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.show()


# In[19]:


PR_variation_df = pd.DataFrame({'precision': precision, 'recall': recall}, index=list(thresholds)+[1])
PR_variation_df.plot(figsize=(10,7))
plt.xlabel('Threshold')
plt.ylabel('P/R values')
plt.show()


# In[20]:


final_threshold = 0.05


# In[21]:


pred_probs_test = np.array([each[1] for each in gbc.predict_proba(X_test)])
preds_test = (pred_probs_test > final_threshold).astype(int)
print(preds_test)


# In[22]:


with open('final_predictions.csv', 'w') as f:
    f.writelines([str(val)+'\n' for val in preds_test])


# In[23]:


with open('final_predictions.csv', 'w') as f:
    f.writelines([str(val)+'\n' for val in preds_test])


# In[24]:


with open('final_predictions.csv', 'w') as f:
    f.writelines([str(val)+'\n' for val in preds_test])


# In[ ]:




